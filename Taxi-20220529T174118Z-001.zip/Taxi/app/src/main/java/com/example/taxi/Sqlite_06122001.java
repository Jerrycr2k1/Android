package com.example.taxi;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class Sqlite_06122001 extends SQLiteOpenHelper {

    public static final String TableName = "Taxi_MaDe1";

    public static final String ID = "Id";
    public static final String SOXE = "SoXe";
    public static final String QUANGDUONG = "QuangDuong";
    public static final String DONGIA = "DonGia";
    public static final String KHUYENMAI = "KhuyenMai";

    public Sqlite_06122001(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String SQLCreate="Create table if not exists "+TableName+"("
                +ID+" Integer primary key autoincrement, "
                +SOXE+" Text , "
                +QUANGDUONG+" Float, "
                +DONGIA+" BIGINT, "
                +KHUYENMAI+" Integer)";
        sqLiteDatabase.execSQL(SQLCreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("Drop table if exists " + TableName);
        onCreate(sqLiteDatabase);
    }
    public void addTaxi(Taxi_MaDe sv) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ID, sv.getId());
        values.put(SOXE, sv.getSoXe());
        values.put(QUANGDUONG, sv.getQuangDuong());
        values.put(DONGIA, sv.getDonGia());
        values.put(KHUYENMAI, sv.getKhuyenMai());

        db.insert(TableName, null,  values);
        db.close();
    }

    public void updateTaxi(int id, Taxi_MaDe sv) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(QUANGDUONG, sv.getQuangDuong());
        values.put(DONGIA, sv.getDonGia());
        values.put(KHUYENMAI, sv.getKhuyenMai());


        db.update(TableName, values, ID +" =? ", new String[]{String.valueOf(id)});
        db.close();
    }

    public void deleteTaxi(String SoXe) {
        SQLiteDatabase db = this.getWritableDatabase();

        String sql = "Delete from " + TableName + " where SoXe like '%" + SoXe+ "%'";
        db.execSQL(sql);
        db.close();
    }

    public ArrayList<Taxi_MaDe> getBySoXe(String soxe) {
        ArrayList<Taxi_MaDe> list = new ArrayList<>();
        String sql = "select * from " + TableName + " where SoXe like '%" + soxe + "%'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        if(cursor != null) {
            while (cursor.moveToNext()) {
                Taxi_MaDe sv = new Taxi_MaDe( cursor.getString(0),
                        cursor.getFloat(1),
                        cursor.getLong(2),
                        cursor.getInt(3));
                list.add(sv);
            }
        }
        return list;
    }

    public ArrayList<Taxi_MaDe> getAll() {
        ArrayList<Taxi_MaDe> list = new ArrayList<>();
        String sql = "select * from " + TableName + " order by SoXe";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        if(cursor != null) {
            while (cursor.moveToNext()) {
                Taxi_MaDe sv = new Taxi_MaDe(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getFloat(2),
                        cursor.getLong(3),
                        cursor.getInt(4));
                list.add(sv);
            }
        }
        return list;
    }
}
