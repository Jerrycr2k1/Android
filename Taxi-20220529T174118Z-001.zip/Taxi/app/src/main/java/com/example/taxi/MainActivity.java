package com.example.taxi;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView lvTaxi;
    ArrayList<Taxi_MaDe> listData;
    Adapter_MaDe adapter;
    Sqlite_06122001 myDb;
    Taxi_MaDe obj ;

    int id;
    boolean check = false;
    ImageView btnAdd;
    EditText searchText;

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Mnu_Edit:
                obj = (Taxi_MaDe) lvTaxi.getItemAtPosition(id);
                Intent intent = new Intent(MainActivity.this, Add_Taxi.class);
                Bundle bundle = new Bundle();
                bundle.putString("SOXE",obj.getSoXe());
                bundle.putFloat("QUANGDUONG",obj.getQuangDuong());
                bundle.putLong("DONGIA",obj.getDonGia());
                bundle.putInt("KHUYENMAI",obj.getKhuyenMai());
                bundle.putBoolean("check",true);
                intent.putExtras(bundle);
                startActivityForResult(intent, 100);
                break;
            case R.id.Mnu_Delete:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Xoá");
                builder.setMessage("Bạn có muốn xóa không");
                builder.setPositiveButton("Đồng ý", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        myDb.deleteTaxi(listData.get(id).getSoXe());
                        listData.remove(id);

                        adapter.notifyDataSetChanged();
                        lvTaxi.setAdapter(adapter);
                    }
                });
                builder.setNegativeButton("Huỷ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = new MenuInflater(this);
        inflater.inflate(R.menu.contextmenu_item, menu);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bundle bundle = data.getExtras();
        int idBundle = bundle.getInt("ID");
        String soXe = bundle.getString("SOXE");
        float quangDuong = bundle.getFloat("QUANGDUONG");
        long donGia = bundle.getLong("DONGIA");
        int khuyenMai = bundle.getInt("KHUYENMAI");
        int index = -2;
        for (Taxi_MaDe item :
                listData) {
            if(item.getSoXe().equals(soXe) )
                index = listData.indexOf(item);
        }
        if(bundle.getBoolean("checkEdit")) {
            myDb.updateTaxi(idBundle, new Taxi_MaDe(soXe, quangDuong, donGia, khuyenMai));
            listData.set(index, new Taxi_MaDe(soXe, quangDuong, donGia, khuyenMai));
        }
//        else if(requestCode==100 && resultCode == 200) {
//            if(index >= 0) {
//                Toast.makeText(MainActivity.this, "Đã có contact id = " + idBundle, Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(MainActivity.this, Add_Contact.class);
//                startActivityForResult(intent, 100);
//            }
//
//            listData.add(new Contact_NgoTrungHieu(idBundle,  name, phone));
//            myDb.addContact(new Contact_NgoTrungHieu(idBundle, name, phone));
//        }
        adapter.notifyDataSetChanged();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvTaxi=findViewById(R.id.listContact);
        //dang ky view cho context view
        registerForContextMenu(lvTaxi);
        listData = new ArrayList<>();
        myDb = new Sqlite_06122001(this, "Taxi_MaDe1", null, 1);

        myDb.addTaxi(new Taxi_MaDe("29D2-283.34", (float) 12.5, 8800, 5));
        myDb.addTaxi(new Taxi_MaDe("29M3-283.35", (float) 14.3, 8800, 5));
        myDb.addTaxi(new Taxi_MaDe("29T4-283.36", (float) 20, 9000, 8));
        myDb.addTaxi(new Taxi_MaDe("29K1-283.37", (float) 32.5, 5900, 9));
        myDb.addTaxi(new Taxi_MaDe("30K1-283.38", (float) 8.3, 4400, 5));
        myDb.addTaxi(new Taxi_MaDe("30K1-283.39", (float) 8.3, 4400, 5));
        listData = myDb.getAll();
        adapter = new Adapter_MaDe(this, listData);
        lvTaxi.setAdapter(adapter);

        btnAdd = findViewById(R.id.btnAdd);
        searchText = findViewById(R.id.searchTxt);
        searchText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                listData = myDb.getBySoXe(String.valueOf(charSequence));
                adapter = new Adapter_MaDe(MainActivity.this, listData);
                lvTaxi.setAdapter(adapter);
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "test", Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(MainActivity.this, Add_Contact.class);
//                startActivityForResult(intent, 100);
            }
        });
        lvTaxi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                id = i;
                return false;
            }
        });
    }


}