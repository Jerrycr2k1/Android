package com.example.taxi;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Add_Taxi extends AppCompatActivity {
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_taxi);
        EditText EdSoXe=findViewById(R.id.Ed_Soxe);
        EditText EdQuangDuong=findViewById(R.id.ED_QuanDuong);
        EditText EdDonGia=findViewById(R.id.ED_DonGia);
        EditText EdKhuyenMai=findViewById(R.id.ED_KhuyenMai);
        Button btnAdd=findViewById(R.id.Btn_ADD);
        Button btnBack=findViewById(R.id.Btn_Back);
        boolean checkEdit = false;
        Bundle extras = getIntent().getExtras();
        if(extras!=null && extras.getBoolean("check")) {
            EdSoXe.setText(extras.getString("SOXE"));
            EdQuangDuong.setText(String.valueOf(extras.getFloat("QUANGDUONG")));
            EdDonGia.setText(String.valueOf(extras.getLong("DONGIA")));
            EdKhuyenMai.setText(String.valueOf(extras.getInt("KHUYENMAI")));
//            btnAdd.setText("Edit");
            EdSoXe.setEnabled(false);
            checkEdit = true;
        }
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Add_Taxi.this,MainActivity.class);
                startActivity(intent);
            }
        });
        if(checkEdit) {
            btnAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(EdSoXe.getText().length()==0
                            || EdQuangDuong.getText().length()==0
                            || EdDonGia.getText().length()==0
                            || EdKhuyenMai.getText().length()==0){
                        Toast.makeText(Add_Taxi.this, "Bạn phải nhập đủ thông tin", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Intent intent=new Intent(Add_Taxi.this,MainActivity.class);
                    Bundle bundle=new Bundle();
                    bundle.putInt("SOXE",Integer.parseInt(EdSoXe.getText().toString()));
                    bundle.putString("SOXE",EdSoXe.getText().toString());
                    bundle.putBoolean("checkEdit", true);
                    bundle.putFloat("QUANGDUONG",Float.parseFloat(EdQuangDuong.getText().toString()) );
                    bundle.putLong("DONGIA",Long.parseLong(EdDonGia.getText().toString()) );
                    bundle.putInt("KHUYENMAI",Integer.parseInt( EdKhuyenMai.getText().toString()));

                    intent.putExtras(bundle);
                    setResult(200,intent);
                    finish();
                }
            });
        }
//        else {
//            btnAdd.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    if (EdID.getText().length() == 0 || EdName.getText().length() == 0 || EdPhone.getText().length() == 0) {
//                        Toast.makeText(Add_Contact.this, "Bạn phải nhập đủ thông tin", Toast.LENGTH_SHORT).show();
//                        return;
//                    }
//                    Intent intent = new Intent(Add_Contact.this, MainActivity.class);
//                    Bundle bundle = new Bundle();
//                    bundle.putInt("ID", Integer.parseInt(EdID.getText().toString()));
//                    bundle.putBoolean("checkEdit", false);
//                    bundle.putString("NAME", EdName.getText().toString());
//                    bundle.putString("PHONE", EdPhone.getText().toString());
//
//                    intent.putExtras(bundle);
//                    setResult(200, intent);
//                    finish();
//                }
//            });
//        }
    }
}
