package com.example.taxi;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import java.util.ArrayList;

public class Adapter_MaDe extends BaseAdapter implements Filterable {
    private Activity activity;
    private ArrayList<Taxi_MaDe> data;
    private LayoutInflater inflater;

    public Adapter_MaDe(Activity activity, ArrayList<Taxi_MaDe> data) {
        this.activity = activity;
        this.data = data;
        this.inflater=(LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int i) {
        return data.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v=view;
        if(v==null){
            v=inflater.inflate(R.layout.listview_item,null);
            TextView txtSoxe =v.findViewById(R.id.Item_Soxe);
            txtSoxe.setText(data.get(i).getSoXe());
            TextView txtQuangDuong = v.findViewById(R.id.Item_QuangDuong);
            txtQuangDuong.setText("Quãng đường: " + (float) data.get(i).getQuangDuong() + " km");
            TextView txtTongTien =v.findViewById(R.id.Item_TongTien);
            float tongTien = data.get(i).getDonGia() * data.get(i).getQuangDuong()
                    * (100-data.get(i).getKhuyenMai())/100;
            txtTongTien.setText((float) tongTien + "");
        }
        return v;
    }

    @Override
    public Filter getFilter() {
        return null;
    }
}
