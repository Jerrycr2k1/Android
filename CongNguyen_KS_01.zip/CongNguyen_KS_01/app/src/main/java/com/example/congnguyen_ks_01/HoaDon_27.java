package com.example.congnguyen_ks_01;

import java.util.Comparator;

public class HoaDon_27 {
    private int Id;
    private String hoTen;
    private int soPhong;
    private int donGia;
    private int soNgayLT;


    public HoaDon_27(int id, String hoTen, int soPhong, int donGia, int soNgayLT) {
        Id = id;
        this.hoTen = hoTen;
        this.soPhong = soPhong;
        this.donGia = donGia;
        this.soNgayLT = soNgayLT;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public int getSoPhong() {
        return soPhong;
    }

    public void setSoPhong(int soPhong) {
        this.soPhong = soPhong;
    }

    public int getDonGia() {
        return donGia;
    }

    public void setDonGia(int donGia) {
        this.donGia = donGia;
    }

    public int getSoNgayLT() {
        return soNgayLT;
    }

    public void setSoNgayLT(int soNgayLT) {
        this.soNgayLT = soNgayLT;
    }

    public int getTongTien(){
        return donGia * soNgayLT;
    }

    public static Comparator<HoaDon_27> soPhongDESC = (o1, o2) -> {
        int p1 =  Integer.valueOf(o1.getSoPhong());
        int p2 = Integer.valueOf(o2.getSoPhong());
        return Integer.compare(p1,p2);
    };
}
