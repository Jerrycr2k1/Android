package com.example.congnguyen_ks_01;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class MyDb extends SQLiteOpenHelper {

    public static final int DB_VERSION = 1;
    public static final String DB_NAME = "Sqlite_01.db";
    public static final String TABLE_NAME = "HoaDon_27";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "ho_ten";
    public static final String COLUMN_SO_PHONG = "so_phong";
    public static final String COLUMN_DON_GIA = "don_gia";
    public static final String COLUMN_NGAY_LT = "ngay_lt";


    public MyDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlCreate = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_NAME + " TEXT,"
                + COLUMN_SO_PHONG + " INTEGER,"
                + COLUMN_DON_GIA + " INTEGER,"
                + COLUMN_NGAY_LT + " INTEGER)";
        db.execSQL(sqlCreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addValue(HoaDon_27 hoaDon){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_NAME, hoaDon.getHoTen());
        contentValues.put(COLUMN_SO_PHONG, hoaDon.getSoPhong());
        contentValues.put(COLUMN_DON_GIA, hoaDon.getDonGia());
        contentValues.put(COLUMN_NGAY_LT, hoaDon.getSoNgayLT());
        db.insert(TABLE_NAME, null, contentValues);

        db.close();
    }


    public ArrayList<HoaDon_27> getAllValues(){

        SQLiteDatabase db = this.getReadableDatabase();

        String sqlSelect = "SELECT * FROM " + TABLE_NAME;

        Cursor cursor = db.rawQuery(sqlSelect, null);

        ArrayList<HoaDon_27> lstResults = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                lstResults.add(new HoaDon_27(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getInt(2),
                        cursor.getInt(3),
                        cursor.getInt(4)));
            } while (cursor.moveToNext());

        }

        cursor.close();
        db.close();
        return lstResults;
    }
}
