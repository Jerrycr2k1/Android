package com.example.congnguyen_ks_01;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.TextView;

import java.util.ArrayList;

public class Adapter_01 extends BaseAdapter {

    private final Activity myActivity;
    private ArrayList<HoaDon_27> data;
    private ArrayList<HoaDon_27> dataBackUp;
    private final LayoutInflater inflater;

    public Adapter_01(Activity myActivity, ArrayList<HoaDon_27> data) {
        this.myActivity = myActivity;
        this.data = data;
        this.inflater = (LayoutInflater) myActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return data.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null){
            v = inflater.inflate(R.layout.list_item , null);
        }
        TextView txtName = v.findViewById(R.id.txtName);
        txtName.setText(data.get(position).getHoTen());
        TextView txtSoPhong= v.findViewById(R.id.txtPhong);
        txtSoPhong.setText("Phong: " + data.get(position).getSoPhong());
        TextView txtTongTien= v.findViewById(R.id.txtTongTien);
        //txtTongTien.setText(String.valueOf(tinhTongTien(position)));
        txtTongTien.setText(String.valueOf(data.get(position).getTongTien()));
        return v;
    }

    public Filter getFilter(){
        Filter f = new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults fr = new FilterResults();
                // luu tam giu lieu vao databackup
                if(dataBackUp == null)  dataBackUp = new ArrayList<>(data);
                //Neu chuoi de filter rong thi khoi phuc giu lieu
                if(constraint == null || constraint.length() == 0)
                {
                    fr.count = dataBackUp.size();
                    fr.values = dataBackUp;
                }
                //Con neu khong rong thi thuc hien filter
                else{
                    ArrayList<HoaDon_27> newData = new ArrayList<HoaDon_27>();
                    for(HoaDon_27 u : dataBackUp)
                    {
//                        if(u.getName().toLowerCase().contains(charSequence.toString().toLowerCase()))
//                        {
//                            newData.add(u);
//                        }

                        if (u.getTongTien() > Integer.valueOf(constraint.toString())){
                            newData.add(u);
                        }
                    }
                    fr.count = newData.size();
                    fr.values = newData;
                }
                return fr;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                data = new ArrayList<HoaDon_27>();
                ArrayList<HoaDon_27> tmp = (ArrayList<HoaDon_27>)  results.values;
                for(HoaDon_27 u: tmp)
                {
                    data.add(u);
                }
                notifyDataSetChanged();
            }
        };
        return f;
    }


}

