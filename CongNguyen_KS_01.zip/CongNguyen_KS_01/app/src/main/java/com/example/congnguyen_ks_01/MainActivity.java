package com.example.congnguyen_ks_01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    ArrayList<HoaDon_27> lst;
    Adapter_01 myAdapter;
    MyDb mySQLiteDB;
    ListView lvMain;
    FloatingActionButton btnAdd;
    int selectedID = 1;
    EditText etSearch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mapping();

        //addData();

        lst = mySQLiteDB.getAllValues();

        sortBy();

        solveSearch();

        solveListView();
    }

    private void mapping(){
        lvMain = findViewById(R.id.lv_main);
        etSearch = findViewById(R.id.et_search);
        btnAdd = findViewById(R.id.floatingActionButton);
        lst = new ArrayList<>();
        mySQLiteDB = new MyDb(MainActivity.this);
    }

    private void addData(){
        mySQLiteDB.addValue(new HoaDon_27(-1, "Nguyen Van Cong", 27, 200, 10));
        mySQLiteDB.addValue(new HoaDon_27(-1, "Bui Minh Hieu", 301, 200, 8));
        mySQLiteDB.addValue(new HoaDon_27(-1, "Phung Huy Vu", 300, 200, 5));
        mySQLiteDB.addValue(new HoaDon_27(-1, "Nguyen Tran Minh", 205, 200, 2));
        mySQLiteDB.addValue(new HoaDon_27(-1, "Nguyen Thi Thuy", 271, 200, 7));
        mySQLiteDB.addValue(new HoaDon_27(-1, "Bui Nguyet Nga", 222, 200, 10));
    }

    public void sortBy(){
        Collections.sort(lst, HoaDon_27.soPhongDESC);
        Collections.reverse(lst);
        myAdapter = new Adapter_01(this, lst);
        lvMain.setAdapter(myAdapter);
    }


    public void solveSearch(){
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                myAdapter.getFilter().filter(s.toString());
                myAdapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
    public void solveListView(){
        registerForContextMenu(lvMain);
        lvMain.setOnItemLongClickListener((parent, view, position, id) -> {
            selectedID = position;
//            Toast.makeText(this, String.valueOf(id) + "-" + String.valueOf(parent.getItemIdAtPosition(position) + "-" + lstTaxis.get(position).getMaHd()), Toast.LENGTH_SHORT).show();
            int hd = demHoaDon(lst.get(position).getTongTien());
            Toast.makeText(this, "Nguyen Van Cong - " + hd, Toast.LENGTH_SHORT).show();
            return false;
        });
    }

    private int demHoaDon(int tien){
        int res = 0;
        for (int i = 0; i < lst.size(); i++) {
            if (lst.get(i).getTongTien() > tien){
                res++;
            }
        }
        return res;
    }
}