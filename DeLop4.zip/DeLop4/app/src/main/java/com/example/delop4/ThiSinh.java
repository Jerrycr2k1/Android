package com.example.delop4;

import java.util.Comparator;
import java.util.Locale;

public class ThiSinh {
    private String sbd;
    private String hoTen;
    private Double toan;
    private Double ly;
    private Double hoa;

    public ThiSinh(String sbd, String hoTen, Double toan, Double ly, Double hoa) {
        this.sbd = sbd;
        this.hoTen = hoTen;
        this.toan = toan;
        this.ly = ly;
        this.hoa = hoa;
    }

    public String getSbd() {
        return sbd;
    }

    public void setSbd(String sbd) {
        this.sbd = sbd;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public Double getToan() {
        return toan;
    }

    public void setToan(Double toan) {
        this.toan = toan;
    }

    public Double getLy() {
        return ly;
    }

    public void setLy(Double ly) {
        this.ly = ly;
    }

    public Double getHoa() {
        return hoa;
    }

    public void setHoa(Double hoa) {
        this.hoa = hoa;
    }

    public Double getTongDiem(){
        return toan+ly+hoa;
    }

    public static Comparator<ThiSinh> nameAsc = (o1, o2) -> {
        String[] parts1 = o1.getHoTen().toLowerCase().split(" ");
        String[] parts2 = o2.getHoTen().toLowerCase().split(" ");
        String name1 = parts1[parts1.length - 1];
        String name2 = parts2[parts2.length - 1];
        return name1.compareTo(name2);
    };
}
