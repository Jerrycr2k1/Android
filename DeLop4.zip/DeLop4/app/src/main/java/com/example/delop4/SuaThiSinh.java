package com.example.delop4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class SuaThiSinh extends AppCompatActivity {

    EditText edtSBD, edtHoTen, edtToan, edtLy, edtHoa;
    Button btnSua, btnQuayVe;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_thi_sinh);

        mapping();

        getData();

        solveButton();
    }

    private void mapping(){
        edtSBD = findViewById(R.id.et_sbd);
        edtHoTen = findViewById(R.id.et_hoten);
        edtSBD = findViewById(R.id.et_sbd);
        edtToan = findViewById(R.id.et_toan);
        edtLy = findViewById(R.id.et_ly);
        edtHoa = findViewById(R.id.et_hoa);
        btnSua = findViewById(R.id.btn_sua);
        btnQuayVe = findViewById(R.id.btn_back);
    }


    private void getData(){
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        if(bundle != null)
        {
            String soBD = bundle.getString("sbd");
            String hoTen = bundle.getString("ho_ten");
            Double toan = bundle.getDouble("toan");
            Double ly = bundle.getDouble("ly");
            Double hoa = bundle.getDouble("hoa");
            //Toast.makeText(this, soXe, Toast.LENGTH_SHORT).show();
            edtSBD.setText(soBD);
            edtHoTen.setText(hoTen);
            edtToan.setText(String.valueOf(toan));
            edtLy.setText(String.valueOf(ly));
            edtHoa.setText(String.valueOf(hoa));

        }
    }

    private void solveButton(){
        btnQuayVe.setOnClickListener(v -> finish());
        btnSua.setOnClickListener(v -> {

            Intent submitIntent = new Intent();
            Bundle submitBundle = new Bundle();

            submitBundle.putString("sbd",edtSBD.getText().toString());
            submitBundle.putString("ho_ten",edtHoTen.getText().toString());
            submitBundle.putDouble("toan",Double.valueOf(edtToan.getText().toString()));
            submitBundle.putDouble("ly",Double.valueOf(edtLy.getText().toString()));
            submitBundle.putDouble("hoa",Double.valueOf(edtHoa.getText().toString()));

            submitIntent.putExtras(submitBundle);

            setResult(201,submitIntent);

            finish();
        });
    }

}