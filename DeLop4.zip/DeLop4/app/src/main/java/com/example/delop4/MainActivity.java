package com.example.delop4;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {


    ArrayList<ThiSinh> lstThiSinh;
    MyAdapter myAdapter;
    MyDb mySQLiteDB;
    ListView lvMain;
    int selectedID = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mapping();

        addData();

        lstThiSinh = mySQLiteDB.getAllThiSinh();

        sortByName();

        solveListView();
    }

    private void mapping(){
        lvMain = findViewById(R.id.lvMain);
        lstThiSinh = new ArrayList<>();
        mySQLiteDB = new MyDb(MainActivity.this);
    }

    private void addData(){
        mySQLiteDB.addThiSinh(new ThiSinh("SBD01", "Nguyen Van Cong",7.0, 8.0, 9.0));
        mySQLiteDB.addThiSinh(new ThiSinh("SBD02", "Bui Minh Hieu",7.5, 8.5, 9.5));
        mySQLiteDB.addThiSinh(new ThiSinh("SBD03", "Nguyen Doan Luong",7.0, 8.0, 8.0));
        mySQLiteDB.addThiSinh(new ThiSinh("SBD04", "Phung Hoang Long",7.0, 7.0, 9.0));
        mySQLiteDB.addThiSinh(new ThiSinh("SBD05", "Pham Viet Hoang Minh",7.0, 7.0, 7.0));
        mySQLiteDB.addThiSinh(new ThiSinh("SBD06", "Nguyen Tran Tan An",7.0, 8.0, 9.5));
    }

    public void sortByName(){
        Collections.sort(lstThiSinh, ThiSinh.nameAsc);
        myAdapter = new MyAdapter(this, lstThiSinh);
        lvMain.setAdapter(myAdapter);
    }

    public void solveListView(){
        registerForContextMenu(lvMain);
        lvMain.setOnItemLongClickListener((parent, view, position, id) -> {
            selectedID = position;
//            Toast.makeText(this, String.valueOf(id) + "-" + String.valueOf(parent.getItemIdAtPosition(position) + "-" + lstThiSinh.get(position).getSbd()), Toast.LENGTH_SHORT).show();
            return false;
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bundle bundle;
        String SBD, hoTen;
        Double toan, ly, hoa;

        if (data != null){
            bundle = data.getExtras();
            SBD = bundle.getString("sbd");
            hoTen = bundle.getString("ho_ten");
            toan = bundle.getDouble("toan");
            ly = bundle.getDouble("ly");
            hoa = bundle.getDouble("hoa");

        }
        else{
            return;
        }


        if(requestCode == 200 && resultCode == 201)
        {
            mySQLiteDB.updateThiSinh(new ThiSinh(SBD, hoTen, toan, ly, hoa));
            lstThiSinh.set(selectedID,new ThiSinh(SBD, hoTen, toan, ly, hoa));
        }
        //myAdapter.notifyDataSetChanged();
        sortByName();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = new MenuInflater(this);
        inflater.inflate(R.menu.menu_item, menu);
    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menuItemEdit){
            Intent intent = new Intent(MainActivity.this , SuaThiSinh.class);
            Bundle bundle = new Bundle();
            bundle.putString("sbd", lstThiSinh.get(selectedID).getSbd());
            bundle.putString("ho_ten", lstThiSinh.get(selectedID).getHoTen());
            bundle.putDouble("toan", lstThiSinh.get(selectedID).getToan());
            bundle.putDouble("ly", lstThiSinh.get(selectedID).getLy());
            bundle.putDouble("hoa", lstThiSinh.get(selectedID).getHoa());


            intent.putExtras(bundle);
            startActivityForResult(intent,200);
        }
        return super.onContextItemSelected(item);
    }
}