package com.example.delop4;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {

    private final Activity myActivity;
    private final ArrayList<ThiSinh> data;
    private final LayoutInflater inflater;

    public MyAdapter(Activity myActivity, ArrayList<ThiSinh> data) {
        this.myActivity = myActivity;
        this.data = data;
        this.inflater = (LayoutInflater) myActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public String getItemID(int position){
        return data.get(position).getSbd();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null){
            v = inflater.inflate(R.layout.list_item , null);
        }
        TextView txtSBD = v.findViewById(R.id.txtSbd);
        txtSBD.setText(String.valueOf(data.get(position).getSbd()));
        TextView txtName = v.findViewById(R.id.txtName);
        txtName.setText(data.get(position).getHoTen());
        TextView txtDiemTB= v.findViewById(R.id.txtDiemTB);
        txtDiemTB.setText(String.format("%.1f", data.get(position).getTongDiem()));
        return v;
    }
}
