package com.example.delop4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyDb extends SQLiteOpenHelper {
    public static final int DB_VERSION = 1;
    public static final String DB_NAME = "Cong_Sqlite.db";
    public static final String TABLE_NAME = "ThiSinh";

    public static final String COLUMN_SBD = "sbd";
    public static final String COLUMN_NAME = "ho_ten";
    public static final String COLUMN_TOAN = "toan";
    public static final String COLUMN_LY = "ly";
    public static final String COLUMN_HOA = "hoa";


    public MyDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlCreate = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ("
                + COLUMN_SBD + " TEXT PRIMARY KEY, "
                + COLUMN_NAME + " TEXT,"
                + COLUMN_TOAN + " REAL,"
                + COLUMN_LY + " REAL,"
                + COLUMN_HOA + " REAL)";
        db.execSQL(sqlCreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addThiSinh(ThiSinh thiSinh){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        //if (!checkExists(device.getId())){
        contentValues.put(COLUMN_SBD, thiSinh.getSbd());
        contentValues.put(COLUMN_NAME, thiSinh.getHoTen());
        contentValues.put(COLUMN_TOAN, thiSinh.getToan());
        contentValues.put(COLUMN_LY, thiSinh.getLy());
        contentValues.put(COLUMN_HOA, thiSinh.getHoa());
        db.insert(TABLE_NAME, null, contentValues);
        //}

        db.close();
    }


    public void updateThiSinh(ThiSinh thiSinh){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_SBD, thiSinh.getSbd());
        contentValues.put(COLUMN_NAME, thiSinh.getHoTen());
        contentValues.put(COLUMN_TOAN, thiSinh.getToan());
        contentValues.put(COLUMN_LY, thiSinh.getLy());
        contentValues.put(COLUMN_HOA, thiSinh.getHoa());

        db.update(TABLE_NAME, contentValues, COLUMN_SBD + " = ?", new String[] { String.valueOf(thiSinh.getSbd()) });
        db.close();
    }

    public ArrayList<ThiSinh> getAllThiSinh(){

        SQLiteDatabase db = this.getReadableDatabase();

        String sqlSelect = "SELECT * FROM " + TABLE_NAME;

        Cursor cursor = db.rawQuery(sqlSelect, null);

        ArrayList<ThiSinh> lstResults = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                lstResults.add(new ThiSinh(cursor.getString(0),
                        cursor.getString(1),
                        cursor.getDouble(2),
                        cursor.getDouble(3),
                        cursor.getDouble(4)));
            } while (cursor.moveToNext());

        }

        cursor.close();
        return lstResults;
    }


}
